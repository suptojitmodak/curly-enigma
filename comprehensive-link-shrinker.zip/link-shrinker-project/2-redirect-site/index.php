<?php
// Get parameters from URL
$shortCode = $_GET['code'] ?? '';
$step = $_GET['step'] ?? '';

if (empty($shortCode)) {
    header('Location: https://short-link.42web.io');
    exit;
}

// Build next step URL
$nextUrl = '';
switch ($step) {
    case 'redirect':
        // This is the first redirect step, go to first blogger site
        $nextUrl = "https://live-essence.blogspot.com/p/step1.html?code={$shortCode}&step=blogger1_1";
        break;
    default:
        // Fallback to main site
        $nextUrl = 'https://short-link.42web.io';
        break;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirecting...</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Please Wait</h1>
            <p>You will be redirected in <span id="countdown">5</span> seconds...</p>
            
            <div class="progress-container">
                <div class="progress-bar" id="progressBar"></div>
            </div>
            
            <div class="timer-display">
                <div class="timer-circle">
                    <span id="timerText">5</span>
                </div>
            </div>
            
            <p class="info">Please do not close this window</p>
        </div>
    </div>
    
    <script>
        const nextUrl = '<?php echo addslashes($nextUrl); ?>';
        let timeLeft = 5;
        
        const countdownElement = document.getElementById('countdown');
        const timerTextElement = document.getElementById('timerText');
        const progressBar = document.getElementById('progressBar');
        
        function updateTimer() {
            countdownElement.textContent = timeLeft;
            timerTextElement.textContent = timeLeft;
            
            // Update progress bar
            const progress = ((5 - timeLeft) / 5) * 100;
            progressBar.style.width = progress + '%';
            
            if (timeLeft <= 0) {
                window.location.href = nextUrl;
                return;
            }
            
            timeLeft--;
            setTimeout(updateTimer, 1000);
        }
        
        // Start the countdown
        updateTimer();
    </script>
</body>
</html>

