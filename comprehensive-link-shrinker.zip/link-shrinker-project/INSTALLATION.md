# Installation Guide - Comprehensive Link Shrinker

## Prerequisites

- Web hosting with PHP support (PHP 7.4 or higher)
- Multiple domains/subdomains for different components
- Cloudflare account for Turnstile integration
- Blogger accounts for intermediate steps

## Component Deployment

### 1. Link Shortener Website (short-link.42web.io)

1. Upload all files from `1-link-shortener/` to your web hosting root directory
2. Ensure the `data/` directory has write permissions (755 or 777)
3. Configure your web server to support URL rewriting (.htaccess for Apache)
4. Test by visiting your domain and creating a short link

**Required Files:**
- index.php
- shrinking.php
- redirect.php
- .htaccess
- assets/ (CSS, JS)
- data/ (JSON storage)

### 2. Redirect Site (link-shrink.free.nf)

1. Upload all files from `2-redirect-site/` to your hosting
2. No special configuration required
3. Test by visiting with parameters: `?code=test&step=redirect`

**Required Files:**
- index.php
- assets/ (CSS)

### 3. Blogger Integration

1. Access your Blogger dashboard
2. Go to Theme → Edit HTML
3. Find the post content area (usually after `<data:post.body/>`)
4. Insert the code from `3-blogger-integration/blogger-code.html`
5. Save the theme
6. Repeat for all Blogger sites in your network

**Setup Steps:**
- Create multiple Blogger sites
- Add the universal code to each theme
- Create placeholder posts for step1.html and step2.html pages
- Test the timer and continue button functionality

### 4. Verifier Landing Page (verify-your-step.ct.ws)

1. Upload all files from `4-verifier-page/` to your hosting
2. Configure Cloudflare Turnstile:
   - Get site key and secret key from Cloudflare dashboard
   - Update `config.json` with your keys
3. Test the verification flow

**Cloudflare Turnstile Setup:**
1. Go to Cloudflare Dashboard → Turnstile
2. Create a new site
3. Copy the Site Key and Secret Key
4. Update `config.json` with your keys

## Configuration

### Update Domain References

Edit the following files to match your actual domains:

**1-link-shortener/shrinking.php:**
```php
$config = [
    'redirect_site' => 'https://your-redirect-domain.com',
    'verifier_site' => 'https://your-verifier-domain.com',
    'blogger_sites' => [
        'https://your-blog1.blogspot.com',
        'https://your-blog2.blogspot.com',
        // Add more blogger sites
    ],
    // ... rest of config
];
```

**2-redirect-site/index.php:**
Update the next URL generation logic to point to your actual Blogger sites.

**3-blogger-integration/blogger-code.html:**
Update the `nextUrl` generation to point to your actual domains.

**4-verifier-page/config.json:**
```json
{
    "turnstile_site_key": "YOUR_ACTUAL_SITE_KEY",
    "turnstile_secret_key": "YOUR_ACTUAL_SECRET_KEY",
    "timer_seconds": 5,
    "button_text": "Get Link"
}
```

## Testing the Complete Flow

1. **Create a short link** on your main domain
2. **Click the short link** - should redirect to redirect site
3. **Wait 5 seconds** - should redirect to first Blogger site
4. **Complete Blogger steps** - timer → continue button → next step
5. **Complete verification** - timer → Turnstile → original URL

## Security Considerations

1. **File Permissions:** Ensure data directory is writable but not publicly accessible
2. **Input Validation:** The code includes basic URL validation
3. **Rate Limiting:** Consider implementing rate limiting for link creation
4. **Turnstile Keys:** Keep secret keys secure and never expose them in frontend code

## Troubleshooting

### Common Issues:

1. **Short links not working:** Check .htaccess file and URL rewriting
2. **Data not saving:** Check file permissions on data directory
3. **Turnstile not loading:** Verify site key and domain configuration
4. **Blogger code not working:** Ensure code is properly inserted in theme

### Debug Mode:

Add this to the top of any PHP file for debugging:
```php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

## Maintenance

1. **Monitor data file size:** The JSON file will grow over time
2. **Backup regularly:** Keep backups of your data and configuration
3. **Update Blogger sites:** Maintain active content on Blogger sites
4. **Monitor performance:** Check loading times and user experience

## Scaling Considerations

For high-traffic scenarios:
1. Replace JSON storage with a proper database (MySQL, PostgreSQL)
2. Implement caching mechanisms
3. Use CDN for static assets
4. Consider load balancing for multiple servers

