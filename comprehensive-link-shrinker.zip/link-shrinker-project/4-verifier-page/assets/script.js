function startTimer(seconds) {
    let timeLeft = seconds;
    const countdownElement = document.getElementById('countdown');
    const timerTextElement = document.getElementById('timerText');
    const timerSection = document.getElementById('timerSection');
    const verificationSection = document.getElementById('verificationSection');
    
    function updateTimer() {
        countdownElement.textContent = timeLeft;
        timerTextElement.textContent = timeLeft;
        
        if (timeLeft <= 0) {
            // Hide timer section and show verification section
            timerSection.style.display = 'none';
            verificationSection.style.display = 'block';
            return;
        }
        
        timeLeft--;
        setTimeout(updateTimer, 1000);
    }
    
    // Start the countdown
    updateTimer();
}

// Handle form submission
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('verificationForm');
    const getLinkButton = document.getElementById('getLinkButton');
    
    if (form) {
        form.addEventListener('submit', function(e) {
            const turnstileResponse = document.querySelector('[name="cf-turnstile-response"]');
            
            if (!turnstileResponse || !turnstileResponse.value) {
                e.preventDefault();
                alert('Please complete the security verification first.');
                return;
            }
            
            // Show loading state
            getLinkButton.textContent = 'VERIFYING...';
            getLinkButton.disabled = true;
        });
    }
});

// Turnstile callback function
function onTurnstileSuccess(token) {
    const getLinkButton = document.getElementById('getLinkButton');
    if (getLinkButton) {
        getLinkButton.disabled = false;
        getLinkButton.style.background = '#28a745';
        getLinkButton.textContent = 'GET LINK';
    }
}

// Handle Turnstile errors
function onTurnstileError() {
    console.error('Turnstile verification failed');
    alert('Verification failed. Please refresh the page and try again.');
}

// Handle Turnstile expiration
function onTurnstileExpired() {
    const getLinkButton = document.getElementById('getLinkButton');
    if (getLinkButton) {
        getLinkButton.disabled = true;
        getLinkButton.style.background = '#ccc';
        getLinkButton.textContent = 'VERIFICATION EXPIRED';
    }
    alert('Verification expired. Please complete the challenge again.');
}

