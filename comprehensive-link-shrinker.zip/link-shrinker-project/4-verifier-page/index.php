<?php
// Load configuration
$configFile = 'config.json';
$config = json_decode(file_get_contents($configFile), true);

// Get parameters from URL
$shortCode = $_GET['code'] ?? '';
$step = $_GET['step'] ?? '';

if (empty($shortCode)) {
    header('Location: https://short-link.42web.io');
    exit;
}

// In a real implementation, you would fetch the original URL from your database
// For this example, we'll use a placeholder
$originalUrl = 'https://example.com'; // This should be fetched from your link database

// Handle form submission (Turnstile verification)
if ($_POST['cf-turnstile-response'] ?? false) {
    $turnstileResponse = $_POST['cf-turnstile-response'];
    
    // Verify Turnstile response with Cloudflare
    $verifyUrl = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
    $data = [
        'secret' => $config['turnstile_secret_key'],
        'response' => $turnstileResponse,
        'remoteip' => $_SERVER['REMOTE_ADDR']
    ];
    
    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        ]
    ];
    
    $context = stream_context_create($options);
    $result = file_get_contents($verifyUrl, false, $context);
    $response = json_decode($result, true);
    
    if ($response['success']) {
        // Verification successful, redirect to original URL
        header('Location: ' . $originalUrl);
        exit;
    } else {
        $error = 'Verification failed. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your Step</title>
    <link rel="stylesheet" href="assets/style.css">
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Final Step</h1>
            <p>Complete the verification to access your link</p>
            
            <?php if (isset($error)): ?>
                <div class="error-message">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <!-- Timer Section -->
            <div id="timerSection">
                <div class="timer-display">
                    <div class="timer-circle">
                        <span id="timerText"><?php echo $config['timer_seconds']; ?></span>
                    </div>
                </div>
                <p class="timer-info">Please wait <span id="countdown"><?php echo $config['timer_seconds']; ?></span> seconds...</p>
            </div>
            
            <!-- Verification Section -->
            <div id="verificationSection" style="display: none;">
                <div class="verification-info">
                    <p>Complete the security check below:</p>
                </div>
                
                <form method="POST" id="verificationForm">
                    <input type="hidden" name="code" value="<?php echo htmlspecialchars($shortCode); ?>">
                    <input type="hidden" name="step" value="<?php echo htmlspecialchars($step); ?>">
                    
                    <div class="turnstile-container">
                        <div class="cf-turnstile" 
                             data-sitekey="<?php echo $config['turnstile_site_key']; ?>"
                             data-callback="onTurnstileSuccess">
                        </div>
                    </div>
                    
                    <button type="submit" id="getLinkButton" class="get-link-btn" disabled>
                        <?php echo $config['button_text']; ?>
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <script src="assets/script.js"></script>
    <script>
        const timerSeconds = <?php echo $config['timer_seconds']; ?>;
        
        function onTurnstileSuccess(token) {
            document.getElementById('getLinkButton').disabled = false;
        }
        
        // Start the timer
        startTimer(timerSeconds);
    </script>
</body>
</html>

