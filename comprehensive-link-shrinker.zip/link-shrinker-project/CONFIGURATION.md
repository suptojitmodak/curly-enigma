# Configuration Guide - Link Shrinker System

## Overview

This guide explains how to configure and customize the Comprehensive Link Shrinker system according to your specific requirements.

## Core Configuration (shrinking.php)

The main configuration is located in `1-link-shortener/shrinking.php`:

```php
$config = [
    'redirect_site' => 'https://link-shrink.free.nf',
    'verifier_site' => 'https://verify-your-step.ct.ws',
    'blogger_sites' => [
        'https://live-essence.blogspot.com',
        'https://here-arduino.blogspot.com',
        // Add more sites as needed
    ],
    'timers' => [
        'redirect_site' => 5,      // Seconds on redirect page
        'blogger_step1' => 10,     // First blogger step timer
        'blogger_step2' => 15,     // Second blogger step timer
        'blogger_step3' => 20,     // Third blogger step timer
        'verifier' => 5            // Verifier page timer
    ],
    'steps_count' => 5,            // Total steps in the flow
    'data_file' => 'data/data-links.json'
];
```

### Customizing Timers

You can adjust the waiting times for each step:

- **redirect_site**: Time on the initial redirect page
- **blogger_step1**: Timer for first visit to first blogger site
- **blogger_step2**: Timer for second visit to first blogger site  
- **blogger_step3**: Timer for visit to second blogger site
- **verifier**: Timer before Turnstile appears

### Adding More Blogger Sites

To add more blogger sites to the rotation:

1. Add the URL to the `blogger_sites` array
2. Install the blogger integration code on the new site
3. The system will randomly select 2 sites for each shortened link

### Modifying the Flow Steps

To change the number of steps or their sequence, modify the `getNextStepUrl()` function in `shrinking.php`.

## Blogger Integration Configuration

### Timer Customization

In `3-blogger-integration/blogger-code.html`, modify the `stepConfig` object:

```javascript
const stepConfig = {
    'blogger1_1': {
        timer: 10,              // Timer duration
        showProgress: true,     // Show progress bar
        nextStep: 'blogger1_2',
        nextUrl: window.location.origin + '/p/step2.html'
    },
    'blogger1_2': {
        timer: 15,
        showProgress: false,    // Hide progress bar (just text)
        nextStep: 'blogger2_1',
        nextUrl: 'https://second-blog.blogspot.com/p/step1.html'
    }
    // Add more steps as needed
};
```

### Visual Customization

Modify the CSS in the blogger code to match your blog's design:

```css
.link-shrinker-container {
    background: #fff;           // Background color
    border: 3px solid #000;     // Border style
    padding: 20px;              // Internal spacing
    margin: 20px 0;             // External spacing
    box-shadow: 4px 4px 0 #000; // Shadow effect
}
```

## Verifier Page Configuration

### Cloudflare Turnstile Settings

Edit `4-verifier-page/config.json`:

```json
{
    "turnstile_site_key": "YOUR_SITE_KEY",
    "turnstile_secret_key": "YOUR_SECRET_KEY",
    "timer_seconds": 5,
    "button_text": "Get Link",
    "page_title": "Verify Your Step",
    "page_description": "Complete the verification to access your link"
}
```

### Turnstile Appearance

You can customize Turnstile appearance by adding data attributes:

```html
<div class="cf-turnstile" 
     data-sitekey="YOUR_SITE_KEY"
     data-theme="light"         // light, dark, auto
     data-size="normal"         // normal, compact
     data-callback="onTurnstileSuccess">
</div>
```

## Design Customization

### Color Scheme

All components use a consistent brutalist design. To change colors, update the CSS files:

**Primary Colors:**
- Background: `#f0f0f0`
- Card Background: `#fff`
- Border: `#000`
- Text: `#333`
- Accent: `#666`

**Button Colors:**
- Default: `#000`
- Hover: `#333`
- Active: `#555`
- Success: `#28a745`
- Error: `#dc3545`

### Typography

The system uses `'Courier New', monospace` for a technical aesthetic. To change:

```css
body {
    font-family: 'Your Font', sans-serif;
}
```

### Layout Modifications

To change the card-based layout:

```css
.card {
    background: #fff;
    border: 3px solid #000;     // Remove for borderless
    padding: 40px;              // Adjust spacing
    box-shadow: 8px 8px 0 #000; // Remove for flat design
}
```

## Advanced Configuration

### Database Integration

To replace JSON storage with a database:

1. **Create Database Table:**
```sql
CREATE TABLE shortened_links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    short_code VARCHAR(10) UNIQUE,
    original_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    clicks INT DEFAULT 0,
    blogger_sites JSON,
    flow_steps JSON
);
```

2. **Update shrinking.php:**
Replace file operations with database queries.

### Custom Analytics

Add tracking to monitor link performance:

```php
function trackClick($shortCode, $step, $userAgent, $ip) {
    // Log click data for analytics
    $logData = [
        'short_code' => $shortCode,
        'step' => $step,
        'user_agent' => $userAgent,
        'ip' => $ip,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    file_put_contents('logs/clicks.log', json_encode($logData) . "\n", FILE_APPEND);
}
```

### Rate Limiting

Implement rate limiting to prevent abuse:

```php
function checkRateLimit($ip) {
    $rateLimitFile = 'data/rate_limits.json';
    $limits = json_decode(file_get_contents($rateLimitFile), true) ?: [];
    
    $currentTime = time();
    $windowStart = $currentTime - 3600; // 1 hour window
    
    // Clean old entries
    $limits = array_filter($limits, function($timestamp) use ($windowStart) {
        return $timestamp > $windowStart;
    });
    
    // Check current IP
    $ipLimits = array_filter($limits, function($timestamp, $key) use ($ip) {
        return strpos($key, $ip) === 0;
    }, ARRAY_FILTER_USE_BOTH);
    
    if (count($ipLimits) >= 10) { // Max 10 links per hour
        return false;
    }
    
    // Add current request
    $limits[$ip . '_' . $currentTime] = $currentTime;
    file_put_contents($rateLimitFile, json_encode($limits));
    
    return true;
}
```

### Custom URL Patterns

To use custom short code patterns:

```php
function generateShortCode($length = 4, $pattern = 'alphanumeric') {
    switch ($pattern) {
        case 'numeric':
            $characters = '0123456789';
            break;
        case 'alpha':
            $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        case 'alphanumeric':
        default:
            $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            break;
    }
    
    $shortCode = '';
    for ($i = 0; $i < $length; $i++) {
        $shortCode .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $shortCode;
}
```

## Security Configuration

### Input Validation

Enhance URL validation:

```php
function validateUrl($url) {
    // Basic validation
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    
    // Check for malicious patterns
    $blacklist = ['javascript:', 'data:', 'vbscript:'];
    foreach ($blacklist as $pattern) {
        if (stripos($url, $pattern) !== false) {
            return false;
        }
    }
    
    // Check domain whitelist (optional)
    $allowedDomains = ['example.com', 'trusted-site.com'];
    if (!empty($allowedDomains)) {
        $domain = parse_url($url, PHP_URL_HOST);
        if (!in_array($domain, $allowedDomains)) {
            return false;
        }
    }
    
    return true;
}
```

### CSRF Protection

Add CSRF tokens to forms:

```php
// Generate token
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Validate token
if ($_POST && (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token'])) {
    die('CSRF token mismatch');
}
```

## Performance Optimization

### Caching

Implement simple file-based caching:

```php
function getCachedData($key, $expiry = 3600) {
    $cacheFile = "cache/{$key}.cache";
    
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $expiry) {
        return json_decode(file_get_contents($cacheFile), true);
    }
    
    return null;
}

function setCachedData($key, $data) {
    if (!file_exists('cache')) {
        mkdir('cache', 0755, true);
    }
    
    file_put_contents("cache/{$key}.cache", json_encode($data));
}
```

### Asset Optimization

Minify CSS and JavaScript files for production use. Consider using a build process or online minification tools.

## Monitoring and Maintenance

### Log Configuration

Set up comprehensive logging:

```php
function logEvent($level, $message, $context = []) {
    $logEntry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'level' => $level,
        'message' => $message,
        'context' => $context
    ];
    
    file_put_contents('logs/system.log', json_encode($logEntry) . "\n", FILE_APPEND);
}
```

### Health Checks

Create a health check endpoint:

```php
// health.php
header('Content-Type: application/json');

$health = [
    'status' => 'ok',
    'timestamp' => date('c'),
    'checks' => [
        'data_file_writable' => is_writable('data/data-links.json'),
        'cache_dir_exists' => file_exists('cache'),
        'logs_dir_writable' => is_writable('logs')
    ]
];

echo json_encode($health);
```

