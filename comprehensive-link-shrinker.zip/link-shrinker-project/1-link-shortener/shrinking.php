<?php

// Configuration for the shrinking system
$config = [
    'redirect_site' => 'https://link-shrink.free.nf',
    'verifier_site' => 'https://verify-your-step.ct.ws',
    'blogger_sites' => [
        'https://live-essence.blogspot.com',
        'https://here-arduino.blogspot.com',
        'https://tech-insights.blogspot.com',
        'https://daily-updates.blogspot.com',
        'https://creative-minds.blogspot.com'
    ],
    'timers' => [
        'redirect_site' => 5,
        'blogger_step1' => 10,
        'blogger_step2' => 15,
        'blogger_step3' => 20,
        'verifier' => 5
    ],
    'steps_count' => 5,
    'data_file' => 'data/data-links.json'
];

function generateShortCode($length = 4) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $shortCode = '';
    for ($i = 0; $i < $length; $i++) {
        $shortCode .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $shortCode;
}

function saveLink($shortCode, $originalUrl) {
    global $config;
    
    // Ensure data directory exists
    if (!file_exists('data')) {
        mkdir('data', 0755, true);
    }
    
    // Load existing data
    $data = [];
    if (file_exists($config['data_file'])) {
        $jsonData = file_get_contents($config['data_file']);
        $data = json_decode($jsonData, true) ?: [];
    }
    
    // Select random blogger sites for this link
    $selectedBloggers = array_rand($config['blogger_sites'], 2);
    $bloggerSites = [
        $config['blogger_sites'][$selectedBloggers[0]],
        $config['blogger_sites'][$selectedBloggers[1]]
    ];
    
    // Create link entry
    $linkData = [
        'short_code' => $shortCode,
        'original_url' => $originalUrl,
        'created_at' => date('Y-m-d H:i:s'),
        'clicks' => 0,
        'blogger_sites' => $bloggerSites,
        'flow_steps' => [
            'redirect_site' => $config['redirect_site'],
            'blogger1_step1' => $bloggerSites[0] . '/p/step1.html',
            'blogger1_step2' => $bloggerSites[0] . '/p/step2.html',
            'blogger2_step1' => $bloggerSites[1] . '/p/step1.html',
            'verifier' => $config['verifier_site']
        ]
    ];
    
    $data[$shortCode] = $linkData;
    
    // Save data
    file_put_contents($config['data_file'], json_encode($data, JSON_PRETTY_PRINT));
    
    // Return the short link
    return getCurrentDomain() . '/' . $shortCode;
}

function getLinkData($shortCode) {
    global $config;
    
    if (!file_exists($config['data_file'])) {
        return null;
    }
    
    $jsonData = file_get_contents($config['data_file']);
    $data = json_decode($jsonData, true) ?: [];
    
    return $data[$shortCode] ?? null;
}

function incrementClickCount($shortCode) {
    global $config;
    
    if (!file_exists($config['data_file'])) {
        return;
    }
    
    $jsonData = file_get_contents($config['data_file']);
    $data = json_decode($jsonData, true) ?: [];
    
    if (isset($data[$shortCode])) {
        $data[$shortCode]['clicks']++;
        $data[$shortCode]['last_clicked'] = date('Y-m-d H:i:s');
        file_put_contents($config['data_file'], json_encode($data, JSON_PRETTY_PRINT));
    }
}

function getCurrentDomain() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    return $protocol . '://' . $_SERVER['HTTP_HOST'];
}

function getNextStepUrl($shortCode, $currentStep = 'start') {
    global $config;
    
    $linkData = getLinkData($shortCode);
    if (!$linkData) {
        return null;
    }
    
    $steps = $linkData['flow_steps'];
    
    switch ($currentStep) {
        case 'start':
            return $steps['redirect_site'] . '?code=' . $shortCode . '&step=redirect';
        case 'redirect':
            return $steps['blogger1_step1'] . '?code=' . $shortCode . '&step=blogger1_1';
        case 'blogger1_1':
            return $steps['blogger1_step2'] . '?code=' . $shortCode . '&step=blogger1_2';
        case 'blogger1_2':
            return $steps['blogger2_step1'] . '?code=' . $shortCode . '&step=blogger2_1';
        case 'blogger2_1':
            return $steps['verifier'] . '?code=' . $shortCode . '&step=verifier';
        case 'verifier':
            return $linkData['original_url'];
        default:
            return null;
    }
}

function buildRedirectUrl($shortCode, $step, $nextStep) {
    $nextUrl = getNextStepUrl($shortCode, $step);
    return $nextUrl;
}

// Export configuration for use in other files
function getConfig() {
    global $config;
    return $config;
}
?>

