<?php
require_once 'shrinking.php';

$message = '';
$shortLink = '';

if ($_POST['url'] ?? false) {
    $originalUrl = trim($_POST['url']);
    
    // Validate URL
    if (filter_var($originalUrl, FILTER_VALIDATE_URL)) {
        $shortCode = generateShortCode();
        $shortLink = saveLink($shortCode, $originalUrl);
        $message = 'Link shortened successfully!';
    } else {
        $message = 'Please enter a valid URL.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link Shortener</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Link Shortener</h1>
            <p>Shorten your long URLs quickly and easily</p>
            
            <?php if ($message): ?>
                <div class="message <?php echo $shortLink ? 'success' : 'error'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($shortLink): ?>
                <div class="result">
                    <label>Your shortened link:</label>
                    <div class="link-result">
                        <input type="text" value="<?php echo htmlspecialchars($shortLink); ?>" readonly id="shortLink">
                        <button onclick="copyLink()" class="copy-btn">Copy</button>
                    </div>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="url-form">
                <div class="input-group">
                    <input type="url" name="url" placeholder="Enter your URL here..." required>
                    <button type="submit">Shorten</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="assets/script.js"></script>
</body>
</html>

