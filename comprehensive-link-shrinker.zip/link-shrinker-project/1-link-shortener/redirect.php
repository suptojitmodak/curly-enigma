<?php
require_once 'shrinking.php';

// Get the short code from URL
$requestUri = $_SERVER['REQUEST_URI'];
$shortCode = trim(parse_url($requestUri, PHP_URL_PATH), '/');

// Remove any query parameters from the short code
if (strpos($shortCode, '?') !== false) {
    $shortCode = substr($shortCode, 0, strpos($shortCode, '?'));
}

// Skip if it's a file request or empty
if (empty($shortCode) || strpos($shortCode, '.') !== false || $shortCode === 'index.php') {
    header('Location: /');
    exit;
}

// Get link data
$linkData = getLinkData($shortCode);

if (!$linkData) {
    // Link not found
    header('HTTP/1.0 404 Not Found');
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Link Not Found</title>
        <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
            .error { color: #e74c3c; }
        </style>
    </head>
    <body>
        <h1 class="error">Link Not Found</h1>
        <p>The shortened link you clicked does not exist or has expired.</p>
        <a href="/">Create a new short link</a>
    </body>
    </html>';
    exit;
}

// Increment click count
incrementClickCount($shortCode);

// Start the redirection flow
$nextUrl = getNextStepUrl($shortCode, 'start');

if ($nextUrl) {
    header('Location: ' . $nextUrl);
    exit;
} else {
    // Fallback to original URL
    header('Location: ' . $linkData['original_url']);
    exit;
}
?>

