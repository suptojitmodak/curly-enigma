function copyLink() {
    const linkInput = document.getElementById('shortLink');
    const copyBtn = document.querySelector('.copy-btn');
    
    // Select and copy the text
    linkInput.select();
    linkInput.setSelectionRange(0, 99999); // For mobile devices
    
    try {
        document.execCommand('copy');
        
        // Visual feedback
        const originalText = copyBtn.textContent;
        copyBtn.textContent = 'COPIED!';
        copyBtn.style.background = '#28a745';
        
        setTimeout(() => {
            copyBtn.textContent = originalText;
            copyBtn.style.background = '#000';
        }, 2000);
        
    } catch (err) {
        console.error('Failed to copy text: ', err);
        alert('Failed to copy link. Please copy manually.');
    }
}

// Auto-select the shortened link when it appears
document.addEventListener('DOMContentLoaded', function() {
    const shortLinkInput = document.getElementById('shortLink');
    if (shortLinkInput) {
        shortLinkInput.addEventListener('click', function() {
            this.select();
        });
    }
    
    // Form validation
    const urlForm = document.querySelector('.url-form');
    const urlInput = urlForm.querySelector('input[name="url"]');
    
    urlForm.addEventListener('submit', function(e) {
        const url = urlInput.value.trim();
        
        if (!url) {
            e.preventDefault();
            alert('Please enter a URL');
            return;
        }
        
        // Add protocol if missing
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            urlInput.value = 'https://' + url;
        }
    });
    
    // Auto-focus on URL input
    urlInput.focus();
});

